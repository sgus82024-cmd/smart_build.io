<section class="promotions">
    <div class="container">
        <h2 class="about-title">Акции</h2>
        <div class="promotions__grid">
            <?php
            $stmt = $pdo->query("SELECT * FROM promotions WHERE is_active = 1 LIMIT 2");
            while ($promo = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="promo__item">';
                if (!empty($promo['image'])) {
                    echo '<div class="service__image">';
                    echo '<img src="assets/images/' . htmlspecialchars($promo['image']) . '" alt="' . htmlspecialchars($promo['title']) . '">';
                    echo '</div>';
                }
                echo '<h3>' . htmlspecialchars($promo['title']) . '</h3>';
                echo '<p class="price">' . number_format(1000 - (1000 * $promo['discount_value'] / 100), 0, '', ' ') . ' руб./м2</p>';
                echo '<p class="old-price">' . number_format(1000, 0, '', ' ') . ' руб./м2</p>';
                echo '<a href="../pages/promotions.php?id=' . $promo['id'] . '" class="btn">Заказать</a>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</section>

