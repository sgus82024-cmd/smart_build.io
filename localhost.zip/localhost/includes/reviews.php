<section class="reviews">
    <div class="container">
        <h2 class="about-title">Отзывы</h2>
        <div class="reviews__grid">
            <?php
            $db = new PDO('mysql:host=127.0.0.1;dbname=smart_build;charset=utf8mb4', 'root', '');
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $query = "SELECT r.*, u.first_name 
                      FROM reviews r 
                      JOIN users u ON r.user_id = u.id 
                      WHERE r.is_approved = 1 
                      ORDER BY r.created_at DESC 
                      LIMIT 3";
            $stmt = $db->query($query);
            $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Вывод каждого отзыва
            foreach ($reviews as $review) {
                echo '<div class="review__item">';
                
                // Блок с рейтингом
                echo '<div class="review__rating">';
                for ($i = 1; $i <= 5; $i++) {
                    $starClass = $i <= $review['rating'] ? 'star-filled' : 'star-empty';
                    echo '<span class="star ' . $starClass . '">★</span>';
                }
                echo '</div>';
                echo '<div class="review__text">';
                echo '<p>' . htmlspecialchars($review['comment']) . '</p>';
                echo '</div>';
                echo '<div class="review__author">';
                echo '<p>' . htmlspecialchars($review['first_name']) . '</p>';
                echo '</div>';
                
                echo '</div>';
            }
            ?>
        </div>
        <div class="section-footer">
            <a href="../pages/reviews.php" class="btn">Смотреть все отзывы <svg width="22" height="16" viewBox="0 0 22 16"  xmlns="http://www.w3.org/2000/svg">
<path d="M21.7071 8.70711C22.0976 8.31658 22.0976 7.68342 21.7071 7.29289L15.3431 0.928932C14.9526 0.538408 14.3195 0.538408 13.9289 0.928932C13.5384 1.31946 13.5384 1.95262 13.9289 2.34315L19.5858 8L13.9289 13.6569C13.5384 14.0474 13.5384 14.6805 13.9289 15.0711C14.3195 15.4616 14.9526 15.4616 15.3431 15.0711L21.7071 8.70711ZM0 8V9H21V8V7H0V8Z" />
</svg>
</a>
        </div>
    </div>
</section>