<div class="slider-container">
<div class="slider">
        
        <div class="slide active">
            <div class="foto">
                <div class="dark-overlay"></div>
                <img src="../assets/images/Slide3.png" alt="Slide 1">
                <div class="info-slide">
                    <h4>вашему вниманию</h4>
                    <h1>майская акция</h1>
                    <h4>50% скидки в честь майских</h4>
                    <div class="sale">
                    <img src="../assets/images/sale.png" alt=""></div>
                    <h6>номер 1 в СНГ</h6>
                </div>
            </div>
        </div>
        
        
        <div class="slide">
        <div class="foto">
                <div class="dark-overlay"></div>
                <img src="../assets/images/Slide4.png" alt="Slide 1">
                <div class="info-slide">
                    <h4>вашему вниманию</h4>
                    <h1>Летние скидки 40% на покраску валиком</h1>
                    <h4>только у Smart Build вы найдёте такие скидки</h4>
                    <div class="sale">
                    <img src="../assets/images/sale.png" alt=""></div>
                    <h6>номер 1 в СНГ</h6>
                </div>
            </div>
        </div>
    </div>


    <!-- Кнопки навигации слайдера с вашими SVG -->
    <button class="slider-btn slider-btn-prev">
        <svg width="25" height="46" viewBox="0 0 25 46" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.95464 23.0002L23.481 1.46729ZM23.481 44.5331L1.01286 22.0581Z" fill="black"/>
            <path d="M1.95464 23.0002L23.481 1.46729M23.481 44.5331L1.01286 22.0581" stroke="#7A1E4C" stroke-width="2.69161"/>
        </svg>
    </button>
    
    <button class="slider-btn slider-btn-next">
        <svg width="25" height="46" viewBox="0 0 25 46" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0454 22.9998L1.51904 44.5327L23.0454 22.9998ZM1.51904 1.46695L23.9871 23.9419L1.51904 1.46695Z" fill="black"/>
            <path d="M23.0454 22.9998L1.51904 44.5327M1.51904 1.46695L23.9871 23.9419" stroke="#0986B8" stroke-width="2.69161"/>
        </svg>
    </button>
    
    <!-- Точки навигации -->
    <div class="slider-dots">
    <button class="slider-dot active" data-slide="0"></button>
    <button class="slider-dot" data-slide="1"></button>
</div>
</div>

    <script>
       document.addEventListener('DOMContentLoaded', function() {
    const slider = document.querySelector('.slider');
    const prevBtn = document.querySelector('.slider-btn-prev');
    const nextBtn = document.querySelector('.slider-btn-next');
    const dots = document.querySelectorAll('.slider-dot');
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    const slideCount = slides.length;
    
    // Функция для переключения слайдов
    function goToSlide(slideIndex) {
        // Зацикливание слайдов
        if (slideIndex < 0) slideIndex = slideCount - 1;
        if (slideIndex >= slideCount) slideIndex = 0;
        
        currentSlide = slideIndex;
        
        // Анимация перехода слайдов
        slider.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // Обновление активной точки
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
        
        // Обновление активного слайда
        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === currentSlide);
        });
    }
    
    // Обработчики событий для кнопок
    prevBtn.addEventListener('click', () => goToSlide(currentSlide - 1));
    nextBtn.addEventListener('click', () => goToSlide(currentSlide + 1));
    
    // Обработчики событий для точек
    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            goToSlide(parseInt(dot.dataset.slide));
        });
    });
    
    // Автоматическое перелистывание (опционально)
    let slideInterval = setInterval(() => {
        goToSlide(currentSlide + 1);
    }, 9000);
    
   
    
    // Инициализация первого слайда
    goToSlide(0);
});
    </script>