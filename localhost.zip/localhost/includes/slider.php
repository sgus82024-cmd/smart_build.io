<div class="slider-container">
<div class="slider">
        
        <div class="slide active">
            <div class="foto">
                <div class="dark-overlay"></div>
                <img src="../assets/images/slide1.jpg" alt="Slide 1">
                <div class="info-slide">
                    <h4>Компания</h4>
                    <h1>SMART BUILD</h1>
                    <h4>Лучшая компания по ремонту квартир и коттеджей</h4>
                    <a href="" id="requestBtn" class="order-btn">Оформить заявку</a>
                    <h6>номер 1 в СНГ</h6>
                </div>
            </div>
        </div>
        
        <div class="slide">
            <<div class="foto">
                <div class="dark-overlay"></div>
                <img src="../assets/images/slide2.jpg" alt="Slide 1">
                <div class="info-slide">
                    <h4>Сейчас  вы наблюдаете</h4>
                    <h1 style=" width: 750px;">Пример одной из работ</h1>
                    <h4>Сделали капитальный ремонт,всего за 7 дней</h4>
                    <button class="order-btn">Оформить заявку</button>
                    <h6>номер 1 в СНГ</h6>
                </div>
            </div>
        </div>
        
        <div class="slide">
        <div class="foto">
                <div class="dark-overlay"></div>
                <img src="../assets/images/Slide3.png" alt="Slide 1">
                <div class="info-slide">
                    <h4>вашему вниманию</h4>
                    <h1>майская акция</h1>
                    <h4>50% скидки в честь майских</h4>
                    <div class="sale">
                    <a href="/pages/promotions.php" class="order-btn">перейти к акциям </a><img src="assets\images\sale.png" alt=""></div>
                    <h6>номер 1 в СНГ</h6>
                </div>
            </div>
        </div>
    </div>


    <!-- Кнопки навигации слайдера с вашими SVG -->
    <button class="slider-btn slider-btn-prev">
        <svg width="25" height="46" viewBox="0 0 25 46" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.95464 23.0002L23.481 1.46729ZM23.481 44.5331L1.01286 22.0581Z" fill="black"/>
            <path d="M1.95464 23.0002L23.481 1.46729M23.481 44.5331L1.01286 22.0581" stroke="#7A1E4C" stroke-width="2.69161"/>
        </svg>
    </button>
    
    <button class="slider-btn slider-btn-next">
        <svg width="25" height="46" viewBox="0 0 25 46" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.0454 22.9998L1.51904 44.5327L23.0454 22.9998ZM1.51904 1.46695L23.9871 23.9419L1.51904 1.46695Z" fill="black"/>
            <path d="M23.0454 22.9998L1.51904 44.5327M1.51904 1.46695L23.9871 23.9419" stroke="#0986B8" stroke-width="2.69161"/>
        </svg>
    </button>
    
    <!-- Точки навигации -->
    <div class="slider-dots">
    <button class="slider-dot active" data-slide="0"></button>
    <button class="slider-dot" data-slide="1"></button>
    <button class="slider-dot" data-slide="2"></button>
</div>
</div>



<!-- Модальное окно для заявки -->
<div id="requestModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 class="section-title">Оставить заявку на ремонт</h2>
        <form id="repairRequestForm">
            <div class="form-group-header">
                <label for="service">Выберите услугу:</label>
                <select id="service" name="service" required>
                    <option value="" disabled selected>-- Выберите услугу --</option>
                    <?php
                    // Подключение к базе данных
                    $db = new PDO('mysql:host=127.0.0.1;dbname=smart_build;charset=utf8', 'root', '');
                    
                    // Запрос для получения активных услуг
                    $servicesQuery = $db->query("SELECT id, title FROM services WHERE is_active = 1");
                    $services = $servicesQuery->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($services as $service) {
                        echo '<option value="' . htmlspecialchars($service['id']) . '">' . htmlspecialchars($service['title']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group-header">
                <label for="promotion">Выберите акцию (если есть):</label>
                <select id="promotion" name="promotion">
                    <option value="" selected>-- Без акции --</option>
                    <?php
                    // Запрос для получения активных акций
                    $promotionsQuery = $db->query("SELECT id, title FROM promotions WHERE is_active = 1 AND end_date >= CURDATE()");
                    $promotions = $promotionsQuery->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($promotions as $promotion) {
                        echo '<option value="' . htmlspecialchars($promotion['id']) . '">' . htmlspecialchars($promotion['title']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            
            <div class="form-group-header">
                <label for="address">Адрес объекта:</label>
                <input type="text" id="address" name="address" required placeholder="Введите адрес, где нужно выполнить работы">
            </div>
            
            <div class="form-group-header">
                <label for="description">Подробное описание работ:</label>
                <textarea id="description" name="description" required placeholder="Опишите, какие именно работы нужно выполнить, ваши пожелания и требования"></textarea>
            </div>
            
            <button type="submit" class="submit_btn1">Отправить заявку</button>
        </form>
    </div>
</div>



<script>
// Универсальная функция для управления модальными окнами
function setupModal(modalId, btnClass) {
    // Открытие модального окна при клике на кнопки с указанным классом
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains(btnClass)) {
            e.preventDefault();
            const modal = document.getElementById(modalId);
            modal.style.display = "block";
            document.body.style.overflow = "hidden";
            
            // Если это кнопка в карточке услуги, устанавливаем соответствующую услугу
            if (e.target.classList.contains('order-btn')) {
                const serviceTitle = e.target.closest('.service__item').querySelector('.service__title--3x2').textContent;
                document.getElementById('service').value = serviceTitle;
            }
        }
    });
    
    // Закрытие модального окна
    const modal = document.getElementById(modalId);
    const span = modal.querySelector(".close");
    
    span.onclick = function() {
        modal.style.display = "none";
        document.body.style.overflow = "auto";
    }
    
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
            document.body.style.overflow = "auto";
        }
    }
}

// Инициализация модального окна для заявок
setupModal("requestModal", "order-btn");

// Обработка отправки формы заявки
document.getElementById("repairRequestForm").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("Заявка отправлена! Мы свяжемся с вами в ближайшее время.");
    document.getElementById("requestModal").style.display = "none";
    document.body.style.overflow = "auto";
    this.reset(); // Очистка формы после отправки
});
</script>



    <script>
       document.addEventListener('DOMContentLoaded', function() {
    const slider = document.querySelector('.slider');
    const prevBtn = document.querySelector('.slider-btn-prev');
    const nextBtn = document.querySelector('.slider-btn-next');
    const dots = document.querySelectorAll('.slider-dot');
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    const slideCount = slides.length;
    
    // Функция для переключения слайдов
    function goToSlide(slideIndex) {
        // Зацикливание слайдов
        if (slideIndex < 0) slideIndex = slideCount - 1;
        if (slideIndex >= slideCount) slideIndex = 0;
        
        currentSlide = slideIndex;
        
        // Анимация перехода слайдов
        slider.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // Обновление активной точки
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
        
        // Обновление активного слайда
        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === currentSlide);
        });
    }
    
    // Обработчики событий для кнопок
    prevBtn.addEventListener('click', () => goToSlide(currentSlide - 1));
    nextBtn.addEventListener('click', () => goToSlide(currentSlide + 1));
    
    // Обработчики событий для точек
    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            goToSlide(parseInt(dot.dataset.slide));
        });
    });
    
    // Автоматическое перелистывание (опционально)
    let slideInterval = setInterval(() => {
        goToSlide(currentSlide + 1);
    }, 9000);
    
   
    
    // Инициализация первого слайда
    goToSlide(0);
});
    </script>