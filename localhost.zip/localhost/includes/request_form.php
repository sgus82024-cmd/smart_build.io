<style>.success-message{text-align:center;} .error-message{text-align:center;}</style>
<section class="request-form" id="request">
    <div class="form-container">
        <h1>ЗАИНТЕРЕСОВАЛИСЬ НАШИМИ УСЛУГАМИ</h1>
        <p class="subtitle">Оставьте заявку на ремонт и мы вам позвоним!!!!!!</p>
        
        <?php
            require_once __DIR__ . '/../includes/db.php';

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            
            try {
                $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // Получение и очистка данных
                $full_name = htmlspecialchars($_POST['full_name'] ?? '');
                $phone = htmlspecialchars($_POST['phone'] ?? '');
                $city = htmlspecialchars($_POST['city'] ?? '');
                
                // Вставка в базу данных
                $stmt = $pdo->prepare("INSERT INTO request_for_call (full_name, phone, city, status) VALUES (?, ?, ?, 'new')");
                $stmt->execute([$full_name, $phone, $city]);
                
                echo '<div class="success-message">Спасибо! Ваша заявка принята. Мы скоро вам перезвоним.</div>';
            } catch (PDOException $e) {
                echo '<div class="error-message">Ошибка при отправке заявки. Пожалуйста, попробуйте позже.</div>';
            }
        }
        ?>
        
        <form class="contact-form" method="POST">
            <div class="form-group">
                <label>Введите Ф.И.О.</label>
                <input type="text" name="full_name" placeholder="Имя Фамилия" class="form-input" required>
            </div>
            
            <div class="form-group">
                <label>Введите номер телефона</label>
                <input type="tel" name="phone" placeholder="+7" class="form-input" required>
            </div>
            
            <div class="form-group">
                <label>Выберите ваш город</label>
                <select class="form-select" name="city" required>
                    <option value="Ижевск">Ижевск</option>
                    <option value="Москва">Москва</option>
                    <option value="Санкт-Петербург">Санкт-Петербург</option>
                </select>
            </div>
            
            <button type="submit" class="submit-btn">ОСТАВИТЬ ЗАЯВКУ</button>
        </form>
    </div>
</section>