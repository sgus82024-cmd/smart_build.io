<?php
function getStatusText($status) {
    $statuses = [
        'new' => 'Новая',
        'in_progress' => 'В работе',
        'completed' => 'Завершена',
        'canceled' => 'Отменена'
    ];
    return $statuses[$status] ?? $status;
}

function isAdmin($user_id, $pdo) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_roles WHERE user_id = ? AND role_id = 1");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() > 0;
}

function isManager($user_id, $pdo) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_roles WHERE user_id = ? AND role_id = 2");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() > 0;
}

function getServices($pdo) {
    $stmt = $pdo->query("SELECT * FROM services WHERE is_active = 1");
    return $stmt->fetchAll();
}

function getServiceCategories($pdo) {
    $stmt = $pdo->query("SELECT * FROM service_categories");
    return $stmt->fetchAll();
}

function getPromotions($pdo) {
    $stmt = $pdo->query("SELECT * FROM promotions WHERE is_active = 1 AND end_date >= CURDATE()");
    return $stmt->fetchAll();
}

function getProjects($pdo, $limit = null) {
    $sql = "SELECT * FROM projects WHERE is_featured = 1";
    if ($limit) {
        $sql .= " LIMIT " . (int)$limit;
    }
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll();
}

function getReviews($pdo, $approved = true, $limit = null) {
    $sql = "SELECT r.*, u.first_name, u.last_name 
            FROM reviews r
            JOIN users u ON r.user_id = u.id
            WHERE r.is_approved = " . ($approved ? '1' : '0');
    
    if ($limit) {
        $sql .= " LIMIT " . (int)$limit;
    }
    
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll();
}