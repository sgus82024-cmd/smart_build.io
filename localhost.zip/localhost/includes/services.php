<section class="services">
    <div class="container">
        <h1 class="about-title">Малая часть наших услуг</h1>
        <div class="services__grid">
            <?php
            $stmt = $pdo->query("SELECT * FROM services LIMIT 4");
            while ($service = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="service__item">';
                if (!empty($service['image'])) {
                    echo '<div class="service__image">';
                    echo '<img src="assets/images/' . htmlspecialchars($service['image']) . '" alt="' . htmlspecialchars($service['title']) . '">';
                    echo '</div>';
                }
                echo '<h3>' . htmlspecialchars($service['title']) . '</h3>';
                echo '<p class="price">' . number_format($service['price'], 0, '', ' ') . ' ₽</p>';
                echo '<p class="old-price">' . number_format($service['price'] * 1.4, 0, '', ' ') . ' ₽</p>';
                echo '<a href="../pages/services.php" id="requestBtn' . $service['id'] . '" class="btn">Заказать</a>';
                echo '</div>';
            }
            ?>
        </div>
       
    </div>
</section>