<?php
session_start(); // Добавлено инициализирование сессии
require_once __DIR__ . '/../includes/db.php';
// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    echo '<div class="message error">Пожалуйста, <a href="../ad/login.php">войдите</a>, чтобы оставить отзыв</div>';
    return;
}


// Получаем имя пользователя для приветствия
$user_name = '';
try {
    $stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    $user_name = $user['first_name'] ?? '';
} catch (PDOException $e) {
    // В случае ошибки просто оставляем имя пустым
}

// Обработка формы
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $rating = intval($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : null;
    $user_id = $_SESSION['user_id'];
    
    // Валидация данных
    $errors = [];
    
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Пожалуйста, выберите оценку от 1 до 5';
    }
    
    if (empty($comment)) {
        $errors[] = 'Пожалуйста, напишите ваш отзыв';
    }
    
    // Если ошибок нет, сохраняем отзыв
    if (empty($errors)) {
        try {
            // Сохраняем отзыв
            $stmt = $pdo->prepare("INSERT INTO reviews (user_id, request_id, rating, comment, is_approved, created_at) 
                                  VALUES (?, ?, ?, ?, 0, NOW())");
            $stmt->execute([$user_id, $request_id, $rating, $comment]);
            
            $success_message = 'Спасибо за ваш отзыв! Он будет опубликован после проверки модератором.';
            
            // Очистка полей формы после успешной отправки
            $_POST = [];
        } catch (PDOException $e) {
            $errors[] = 'Произошла ошибка при сохранении отзыва: ' . $e->getMessage();
        }
    }
    
    if (!empty($errors)) {
        $error_message = implode('<br>', $errors);
    }
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<style>
    .reviews_form{
      font-family: 'Roboto Condensed', Arial, sans-serif;
      background-color: #f5f5f5;
      padding: 60px 10px;
      color: #333;
    }

    .reviewstxt {
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .container_reviews_form {
           width: 1200px;
      height: 700px;
      margin: 0 auto;
      background-image: url(https://media.licdn.com/dms/image/v2/C511BAQHwyhgChF32-w/company-background_10000/company-background_10000/0/1583854866040/amplify_social_media_agency_cover?e=2147483647&v=beta&t=BeoB3BUheC_ljJf9UwIHh7-_1fmxBNae1SnMnKJY7tc);
      border-radius: 12px;
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
      transform: scaleX(300deg);
    }
    
    .form-reviews {    
        display: flex;
        flex-direction: column;
        gap: 25px;
        align-items: flex-start;
        flex-wrap: wrap;
        align-content: center;
        transform: scaleX(180deg);
    }
    
    .subtitle-reviews {
       font-family: 'Inter';
        font-style: normal;
        font-weight: 700;
        font-size: 13px;
        line-height: 20px;
        display: flex;
        align-items: center;
        text-align: center;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: #F9FAFB;
        transform: scaleX(180deg);
        justify-content: center;
        padding-top: 33px;
    }
    
    .title-reviews {
       margin: 42px auto;
        font-family: 'Roboto';
        font-style: normal;
        font-weight: 300;
        font-size: 28px;
        line-height: 41px;
        color: #F9FAFB;
        transform: scaleX(180deg);
        display: flex;
        justify-content: center;
    }
    
    .form-group-reviews {
        margin-bottom: 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 8px;
        transform: scaleX(180deg);
    }
    
    label {
           height: 25px;
        font-family: 'Roboto';
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 19px;
        color: #FFFFFF;
        transform: scaleX(180deg);
    }
    
    input[type="text"],
    textarea {
          box-sizing: border-box;
        width: 260px;
        height: 55px;
        color: white;
        background: #222529;
        border: 1px solid #888B93;
        border-radius: 4px;
        padding-left: 10px;
        transform: scaleX(180deg);
    }
    
    input[type="text"]:focus,
    textarea:focus {
        box-shadow: 0 0 0 2px rgb(255, 255, 255);
    }
    
    textarea {
        resize: none;
        height: 8rem;
        padding: 15px;
    }
    
    .star-rating-reviews {
        display: flex;
        margin-top: 10px;
    }
    
    .star-rating-reviews input {
        display: none;
    }
    
    .star-rating-reviews label {
        cursor: pointer;
        font-size: 1.5rem;
        padding: 0 0.25rem;
        color: #b02a63;
        transition: color 0.2s;    
        box-sizing: border-box;
        border-radius: 4px;
        padding-left: 10px;
    }
    
    .star-rating-reviews input:checked ~ label {
        color: #6b7280;
    }
    
    .star-rating-reviews label:hover,
    .star-rating-reviews label:hover ~ label,
    .star-rating-reviews input:checked + label {
        color: #b02a63;
    }
    
    .submit-btn-reviews {
              background: #7A1E4C;
        border: 1px solid #7A1E4C;
        border-radius: 4px;
        color: white;
        border: 1px solid transparent;
        padding: 15px 40px;
        font-size: 12px;
        text-transform: uppercase;
        margin: 5px 0;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-block;
        font-family: "Inter", sans-serif;
        font-weight: 700;
        text-align: center;
        transform: scaleX(180deg);
        display: flex;
        flex-direction: row;
        margin: 0 auto;
    }
    
    
    .submit-btn-reviews:hover {
        background-color: transparent;
        transform: translateY(-2px);
        border: white solid 1px;
        color: white;
    }
    
    .message {
        text-align: center;
        padding: 10px;
        margin: 10px 0;
        border-radius: 4px;
        transform: scaleX(180deg);
    }
    
    .success {
           background-color: #d4edda;
    color: #155724;
    width: 50%;
    display: flex
;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    margin-top: 15%;
    }
    
    .error {
        background-color: #f8d7da;
        color: #721c24;
         width: 50%;
    display: flex
;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    margin-top: 15%;
    }
    
    .user-greeting {
        color: #FFFFFF;
        text-align: center;
        transform: scaleX(180deg);
        margin-bottom: 15px;
        font-family: 'Roboto';
    }
     @media (min-width: 992px) and (max-width: 1199px) {
    .container_reviews_form{
        width: 100%;
        height: 100%;
    }}
     @media (min-width: 768px) and (max-width: 991px) {
    .container_reviews_form{
        width: 100%;
        height: 100%;
    }}
     @media (min-width: 480px) and (max-width: 767px) {
    .container_reviews_form{
        width: 100%;
        height: 100%;
    }}
        @media (min-width: 320px) and (max-width: 479px) {
    .container_reviews_form{
        width: 100%;
        height: 100%;
    }}
    @media (max-width: 640px) {
        .container_reviews_form {
            padding: 1.5rem;
        }
    }
</style>

<div class="reviews_form">
    <div class="container_reviews_form">
        <div class="reviewstxt">
            <h2 class="subtitle-reviews">ПОНРАВИЛИСЬ ЛИ ВАМ НАШИ УСЛУГИ?</h2>
            <h1 class="title-reviews">Оставьте отзыв для улучшения качества обслуживания</h1>
        </div>
        
        <?php if (!empty($user_name)): ?>
            <div class="user-greeting">Здравствуйте, <?= htmlspecialchars($user_name) ?>!</div>
        <?php endif; ?>
        
        <?php if (!empty($success_message)): ?>
            <div class="message success"><?= htmlspecialchars($success_message) ?></div>
        <?php elseif (!empty($error_message)): ?>
            <div class="message error"><?= $error_message ?></div>
        <?php endif; ?>
        
        <?php if (empty($success_message)): ?>
            <form class="form-reviews" method="POST" action="">
                <div class="form-group-reviews">
                    <label>На сколько звёзд <br>оцените нашу компанию?</label>
                    <div class="star-rating-reviews">
                       <?php for ($i = 1; $i <= 5; $i++): ?>
    <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" 
           <?= ($_POST['rating'] ?? 0) == $i ? 'checked' : '' ?>>
    <label for="star<?= $i ?>">★</label>
<?php endfor; ?>
                    </div>
                </div>
                
                <div class="form-group-reviews">
                    <label for="feedback">Напишите отзыв о нашей компании</label>
                    <textarea id="feedback" name="comment" placeholder="Отзыв" required><?= 
                        htmlspecialchars($_POST['comment'] ?? '') 
                    ?></textarea>
                </div>
                
                <?php if (isset($_GET['request_id'])): ?>
                    <input type="hidden" name="request_id" value="<?= intval($_GET['request_id']) ?>">
                <?php endif; ?>
                
                <button name="submit" type="submit" class="submit-btn-reviews">ОСТАВИТЬ ОТЗЫВ</button>
            </form>
        <?php endif; ?>
    </div>
</div>
    <script>
       document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.star-rating-reviews label');
    const radioInputs = document.querySelectorAll('.star-rating-reviews input[type="radio"]');
    
    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            // Удаляем все звезды
            stars.forEach(s => {
                s.style.color = '#6b7280';
            });
            
            // Заполняем до выбранной (включая её)
            for (let i = 0; i <= index; i++) {
                stars[i].style.color = '#b02a63';
            }
            
            // Устанавливаем значение radio
            radioInputs[index].checked = true;
        });
        
        // Добавляем обработчик наведения для предпросмотра
        star.addEventListener('mouseover', () => {
            // Временно подсвечиваем звёзды до текущей
            for (let i = 0; i <= index; i++) {
                stars[i].style.color = '#b02a63';
            }
        });
        
        star.addEventListener('mouseout', () => {
            // Восстанавливаем состояние после наведения
            const checkedIndex = Array.from(radioInputs).findIndex(input => input.checked);
            stars.forEach((s, i) => {
                s.style.color = i <= checkedIndex ? '#b02a63' : '#6b7280';
            });
        });
    });
    
    // Восстановление выбранных звезд при возврате на страницу
    radioInputs.forEach((input, index) => {
        if (input.checked) {
            for (let i = 0; i <= index; i++) {
                stars[i].style.color = '#b02a63';
            }
        }
    });
});
    </script>