<?php
require_once __DIR__ . '/../includes/db.php';
session_start();

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-warning">Пожалуйста, <a href="/login.php">войдите</a>, чтобы оставить отзыв</div>';
    return;
}

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = intval($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : null;
    $user_id = $_SESSION['user_id'];
    
    // Валидация данных
    $errors = [];
    
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Пожалуйста, выберите оценку от 1 до 5';
    }
    
    if (empty($comment)) {
        $errors[] = 'Пожалуйста, напишите ваш отзыв';
    }
    
    // Если ошибок нет, сохраняем отзыв
    if (empty($errors)) {
        try {
            // Сохраняем отзыв
            $stmt = $pdo->prepare("INSERT INTO reviews (user_id, request_id, rating, comment, is_approved) 
                                  VALUES (?, ?, ?, ?, 0)");
            $stmt->execute([$user_id, $request_id, $rating, $comment]);
            
            $success = 'Спасибо за ваш отзыв! Он будет опубликован после проверки модератором.';
        } catch (PDOException $e) {
            $errors[] = 'Произошла ошибка при сохранении отзыва: ' . $e->getMessage();
        }
    }
}

// Получаем имя пользователя для приветствия
$user_name = '';
try {
    $stmt = $pdo->prepare("SELECT first_name FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    $user_name = $user['first_name'] ?? '';
} catch (PDOException $e) {
    // В случае ошибки просто оставляем имя пустым
}
?>

<div class="reviews-section">
    <h2>Оставьте ваш отзыв</h2>
    
    <?php if (!empty($user_name)): ?>
        <p>Здравствуйте, <?= htmlspecialchars($user_name) ?>!</p>
    <?php endif; ?>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php else: ?>
        <form method="POST" class="review-form">
            <div class="form-group">
                <label>Оценка:</label>
                <div class="rating-stars">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" 
                               <?= ($_POST['rating'] ?? 0) == $i ? 'checked' : '' ?>>
                        <label for="star<?= $i ?>">★</label>
                    <?php endfor; ?>
                </div>
            </div>
            
            <div class="form-group">
                <label for="comment">Ваш отзыв:</label>
                <textarea id="comment" name="comment" class="form-control" rows="5" required><?= 
                    htmlspecialchars($_POST['comment'] ?? '') 
                ?></textarea>
            </div>
            
            <?php if (isset($_GET['request_id'])): ?>
                <input type="hidden" name="request_id" value="<?= intval($_GET['request_id']) ?>">
            <?php endif; ?>
            
            <button type="submit" class="btn btn-primary">Отправить отзыв</button>
        </form>
    <?php endif; ?>
</div>

<style>
    .reviews-section {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background: #f9f9f9;
        border-radius: 8px;
    }
    
    .review-form {
        margin-top: 20px;
    }
    
    .form-group {
        margin-bottom: 15px;
    }
    
    .form-control {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    
    .rating-stars {
        display: flex;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    
    .rating-stars input {
        display: none;
    }
    
    .rating-stars label {
        font-size: 24px;
        color: #ccc;
        cursor: pointer;
        padding: 0 5px;
    }
    
    .rating-stars input:checked ~ label,
    .rating-stars input:hover ~ label,
    .rating-stars label:hover,
    .rating-stars label:hover ~ label {
        color: #ffc107;
    }
    
    .alert {
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 4px;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    
    .alert-success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .alert-warning {
        background-color: #fff3cd;
        color: #856404;
        border: 1px solid #ffeeba;
    }
    
    .btn-primary {
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    
    .btn-primary:hover {
        background-color: #0069d9;
    }
</style>